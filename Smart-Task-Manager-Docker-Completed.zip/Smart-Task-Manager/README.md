# Smart Task Manager

A responsive browser-based task manager built with HTML, CSS, and JavaScript, packaged for Docker using Nginx.

## Features
- Add tasks
- Mark tasks as completed and undo completion
- Delete tasks
- Search tasks
- Save tasks in browser Local Storage

## Technologies
- HTML, CSS, JavaScript
- Docker, Docker Compose, Nginx

## Run locally without Docker
Open `index.html` in a modern browser, or use the VS Code Live Server extension.

## Run with Docker Compose
1. Install and start Docker Desktop.
2. Open a terminal in this project folder.
3. Build and start the application:

   ```bash
   docker compose up --build -d
   ```
4. Open http://localhost:8080 in your browser.
5. Stop the application:

   ```bash
   docker compose down
   ```

## Run with Docker commands
Build the image:

```bash
docker build -t smart-task-manager .
```

Run the container:

```bash
docker run -d --name smart-task-manager -p 8080:80 smart-task-manager
```

Open http://localhost:8080.

Stop and remove it:

```bash
docker stop smart-task-manager
docker rm smart-task-manager
```

## Push image to Docker Hub
Replace `YOUR_DOCKERHUB_USERNAME` with your Docker Hub username:

```bash
docker login
docker tag smart-task-manager YOUR_DOCKERHUB_USERNAME/smart-task-manager:latest
docker push YOUR_DOCKERHUB_USERNAME/smart-task-manager:latest
```

## Push project to GitHub
Create an empty GitHub repository, then run these commands from this folder. Replace the URL with your repository URL:

```bash
git init
git add .
git commit -m "Add Dockerized Smart Task Manager"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Storage note
Tasks are saved in the browser's Local Storage. They remain in that browser profile and are not synchronized between browsers or devices.
