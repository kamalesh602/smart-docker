let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const searchInput = document.getElementById("searchInput");
const taskList = document.getElementById("taskList");
const taskCount = document.getElementById("taskCount");

function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function addTask(event) {
    event.preventDefault();

    const taskName = taskInput.value.trim();

    if (taskName === "") {
        alert("Please enter a task!");
        return;
    }

    tasks.push({
        id: Date.now(),
        name: taskName,
        completed: false
    });

    taskInput.value = "";
    saveTasks();
    displayTasks();
}

function displayTasks() {
    const search = searchInput.value.toLowerCase();
    taskList.innerHTML = "";

    const filteredTasks = tasks.filter(task =>
        task.name.toLowerCase().includes(search)
    );

    filteredTasks.forEach(task => {
        const li = document.createElement("li");

        if (task.completed) {
            li.classList.add("completed");
        }

        const span = document.createElement("span");
        span.textContent = task.name;

        const actions = document.createElement("div");
        actions.className = "actions";

        const completeButton = document.createElement("button");
        completeButton.className = "complete";
        completeButton.textContent = task.completed ? "Undo" : "Done";
        completeButton.addEventListener("click", () => toggleTask(task.id));

        const deleteButton = document.createElement("button");
        deleteButton.className = "delete";
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", () => deleteTask(task.id));

        actions.append(completeButton, deleteButton);
        li.append(span, actions);
        taskList.appendChild(li);
    });

    const completedCount = tasks.filter(task => task.completed).length;
    taskCount.textContent =
        `Total Tasks: ${tasks.length} | Completed: ${completedCount}`;
}

function toggleTask(id) {
    tasks = tasks.map(task =>
        task.id === id
            ? { ...task, completed: !task.completed }
            : task
    );

    saveTasks();
    displayTasks();
}

function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    displayTasks();
}

taskForm.addEventListener("submit", addTask);
searchInput.addEventListener("input", displayTasks);

displayTasks();
